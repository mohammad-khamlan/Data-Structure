//
// Created by Ayser Armiti on 19.10.19.
//
#ifndef MINICPU_CPU_H
#define MINICPU_CPU_H

#include<string>
#include "TaskBuffer.h"
#include "Task.h"
#include "../MiniTaskGenerator/CSVhandler.h"
using namespace std;

class CPU {

public:
    /*
     * a constructor the CPU given a path of the file that has the tasks to be
     * executed. Constructor sets the file_path value
     */
    CPU(string file);

    /*
     * get sleeping time for the cpu
     */
    int getSleepTime();

    /*
     * the run function loops for ever. At each loop it does
     * 1- read the content of the tasks file and erase its content
     * 2- add the tasks to the tasks queue
     * 3- serve the current task by one unit
     */
    void run();
private:

    /*
     * returns an array of Tasks stored in the task file
     * this function cleans the tasks file after reading its content
     */
    //Task** readTasksFromFile();

    // a path to the tasks file
    CSVhandler* file_handler;
    // queue buffer holding the tasks
    TaskBuffer* tasks_queue=new TaskBuffer;

};


#endif //MINICPU_CPU_H
