//
// Created by Ayser Armiti on 19.10.19.
//

#include <thread>
#include <chrono>
#include "CPU.h"

const int CPU_SLEEP_LOWER_VAL = 5;
const int CPU_SLEEP_UPPER_RANGE_VAL = 7;


CPU::CPU(string file) {
  //tasks_queue  = new TaskBuffer();
    file_handler = new CSVhandler(file);
}


int CPU::getSleepTime() {
    srand(time(NULL));
    return (rand() % CPU_SLEEP_UPPER_RANGE_VAL + CPU_SLEEP_LOWER_VAL) * 1000;
}


void CPU::run() {
    while (true) {
        vector<tuple<string, int>> tasks = file_handler->readCSV();
        file_handler->eraseCSV();
        for (unsigned long i=0;i<tasks.size();i++) {
            string uuid = get<0>(tasks.at(i));
            int unit = get<1>(tasks.at(i));
            Task *temp = new Task(uuid, unit);
            if(!temp->getUUID().empty())
            tasks_queue->addNewTask(temp);
        }

        tasks_queue->serveCurrentTask();
                int time_to_sleep = this->getSleepTime();
            cout << "CPU is sleeping for " << time_to_sleep << endl;
            this_thread::sleep_for(chrono::milliseconds(time_to_sleep));



    }
}
