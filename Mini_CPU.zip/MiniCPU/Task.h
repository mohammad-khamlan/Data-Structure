//
// Created by Ayser Armiti on 19.10.19.
//

#ifndef MINICPU_TASK_H
#define MINICPU_TASK_H

#include <string>
#include <iostream>

using namespace std;
class Task {

public:
    /*
     * constructor to create a Task with the given needed units and given uuid
     */
    Task(string uuid, int units);

    /*
     * serve the current task. This means the needed_processing_units will decrease by one unit.
     * If current value before serving > 0 then the function return true, if needed_processing_units
     * is zero, then the function returns false
     * if the fuction returns false, it should print
     * <uuid of the taks> is done
     */
    bool serve();

    /*
     * get a pointer to the next Task
     */
    Task * getNextTask();

    /*
     * this function sets the values of the next task
     */
    void setNextTask(Task * next);

    /*
     * gets the uuid
     */
    string getUUID();

    /*
     * gets needed processing units for this task
     */
    int getNeededProcessingUnits();
private:
    // a pointer to the next task
    Task * next_task;
    //number of processing units needed to fully serve this tasks
    int needed_processing_units;
    // and id for the current task
    string task_uuid;

};


#endif //MINICPU_TASK_H
