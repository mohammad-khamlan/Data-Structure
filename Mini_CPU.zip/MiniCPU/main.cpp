#include <iostream>
#include <string>
#include "CPU.h"

using namespace std;

/*
 * the user sends the file path of the tasks to the program as a parameter
 * MiniCPU <path of the file>
 * example: MiniCPU /user/data/tasks.csv
 */
int main(int argc,char* argv[]) {
	//Mohammad Khamlan//11819287
	if(argc == 1){
        cout<< "you need to give the path to the file";
        return -1;
    }

    // get an instance of the CPU given the file of the tasks
    CPU* my_mini_cpu = new CPU(string (argv[1]));
    // start the cpu
    my_mini_cpu->run();
    return 0;
}
