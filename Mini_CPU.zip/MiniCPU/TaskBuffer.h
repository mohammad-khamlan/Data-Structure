//
// Created by Ayser Armiti on 19.10.19.
//

#ifndef MINICPU_TASKBUFFER_H
#define MINICPU_TASKBUFFER_H

#include "Task.h"
class TaskBuffer {

public:
    /*
     * reset the current_size and the current_task members
     */
    TaskBuffer();

    /*
     * serve the current task at the front of the TaskBuffer by calling serve for that task
     * if serve returns false then delete current task using private functions
     * should point to the next task in the buffer
     *
     */
    void serveCurrentTask();

    /*
     * add a new task to the TaskBuffer and adapt the size of the buffer
     * the TaskBuffer should print the following to the screen
     * <uuid of the task> with <number of processing units needed> was added to the TaskBuffer
     */
    void addNewTask(Task* new_task);

private:

    /*
     * delete the current task and decrement buffer_size by one
     */
    void deleteCurrentTask();

    /*
     * returns true if the buffer is empty
     */
    bool isEmpty();

    // stores number of tasks in the buffer
    int buffer_size;
    // points to the current task in the buffer, i.e., the head of the queue
    Task * current_task;
};


#endif //MINICPU_TASKBUFFER_H
