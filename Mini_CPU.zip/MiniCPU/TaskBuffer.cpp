//
// Created by Ayser Armiti on 19.10.19.
//

#include "TaskBuffer.h"
#include "Task.h"

TaskBuffer::TaskBuffer() {
    current_task = nullptr;
    buffer_size = 0;
}

bool TaskBuffer::isEmpty() {
    if (buffer_size==0)
        return true;
    return false;
}


void TaskBuffer::addNewTask(Task* new_task) {
    buffer_size++;
    if (current_task == nullptr) {
        current_task = new_task;
        current_task->setNextTask(new_task);
    }

    else {
        Task* tail=current_task;
        while (tail->getNextTask() != current_task) {
            tail=tail->getNextTask();
        }
        tail->setNextTask(new_task);
        new_task->setNextTask(current_task);
    }
}


void TaskBuffer::deleteCurrentTask() {
    Task* del = current_task;
    buffer_size--;
    while (del->getNextTask() != current_task) {
        del=del->getNextTask();
    }


    del->setNextTask(current_task->getNextTask());
    del = current_task;
    current_task=current_task->getNextTask();
    delete del;
    //if(isEmpty()){} //end program
}

void TaskBuffer::serveCurrentTask() {
    if (!current_task->serve())
        deleteCurrentTask();
    current_task=current_task->getNextTask();

}