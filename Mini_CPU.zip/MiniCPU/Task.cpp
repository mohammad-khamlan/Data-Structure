//
// Created by Ayser Armiti on 19.10.19.
//

#include "Task.h"
#include <string>

Task::Task(string uuid, int units) {
    task_uuid = uuid;
    needed_processing_units = units;
}

Task *Task:: getNextTask() { return next_task; }

void Task::setNextTask(Task * next) { next_task = next; }

string Task::getUUID() { return task_uuid; }

int Task::getNeededProcessingUnits() { return needed_processing_units; }

bool Task::serve() {
    if (needed_processing_units > 0){
        needed_processing_units--;
        cout<<task_uuid<<"  is served   "<<needed_processing_units<<endl;
        return true;
    }
    cout << task_uuid<<" is done"<<endl;
    return false;

}