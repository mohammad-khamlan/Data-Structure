#include <iostream>
#include <string>
#include <ctime>
#include <fstream>
#include <sstream>
#include "CSVhandler.h"

CSVhandler::CSVhandler(string file_name){

	this->file_name=file_name;

}

void CSVhandler::eraseCSV() {
    ofstream ofs;
    ofs.open(this->file_name, std::ofstream::out | std::ofstream::trunc);
    ofs.close();
}
void CSVhandler::writeCSV(tuple <string, int> task){
    fstream myfile(this->file_name,
            std::fstream::in | std::fstream::out | std::fstream::app);

    if(myfile.is_open()) {
        myfile << get<0>(task) << "," << get<1>(task) << '\n';
        cout << "Task was written to " << file_name << endl;
        myfile.flush();
        myfile.close();
    }else{
        cout << "Cannot open file " << file_name << endl;
    }
}


vector<tuple <string, int>>  CSVhandler::readCSV(){
    vector<tuple <string, int>> result;
    /*
        You need to implement this function
    */
    ifstream file;
    file.open( file_name);
    int i = 0; string s;

    while (file.good()) {
        string line;
        getline(file, line);

        s=line.substr(0, line.find(","));

        char a = line[line.length() - 1];
        int x = a - '0';

        result.push_back(make_tuple(s, x));


    }
    return result;
}