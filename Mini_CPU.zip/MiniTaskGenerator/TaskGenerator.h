#ifndef TASK_GENERATOR_H
#define TASK_GENERATOR_H

#include <iostream>
#include <string>
#include "CSVhandler.h"
using namespace std;

class TaskGenerator{

public:

    /*
     * constructor that tasks the file path to save the tasks
     */
	TaskGenerator(string file_name);

	/*
	 * destructor, it deletes file_handler object
	 */
    ~TaskGenerator();

	/*
	 * start generating tasks it loops for ever
	 * 1- generate a task randomly
	 * 2- append it to the tasks file
	 */
	void run();

private:
    /*
     * generate randomly a task and append to the file
     */
    void generateTaskAndAppend();
    /*
     * generate a random UUID
     */
    string uuidGenerator();
    /*
     * get a random value for sleep, the time the task generator should wait till it generates
     * the next task
     */
    int getSleepTime();
    /*
     * generate randomly number of processing units needed to serve that tasks
     */
    int taskUnits();

    // CSVHandler object to save to CSV file
    CSVhandler* file_handler;
};

#endif //TASK_GENERATOR_H