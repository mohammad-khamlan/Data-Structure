#ifndef CSV_HANDLER_H
#define CSV_HANDLER_H

#include <iostream>
#include <string>
#include <tuple>
#include <vector>

using namespace std;

class CSVhandler{

public:

    /*
     * construct to have a CSV file handler
     */
	CSVhandler(string file_name);
    /*
     * the function gets tuple  the first value is the UUID, the second
     * is the number of processing units for that tasks as string. The function append one
     * line to the csv file
     */
	void writeCSV(tuple<string,int> task);

	/*
	 * return a vector of tuples, each tuple represents a task, after reading the content of the
	 * file the readerCSV cleans the file
	 */
    vector<tuple <string, int>>  readCSV();

    /*
     * this function erase the content of the csv file
     */
    void eraseCSV();

private:
    // the path to the file where we want to store the tasks or read them
    string file_name;
};

#endif //CSV_HANDLER_H
