#include <iostream>
#include <ctime>
#include <string>
#include <tuple>
#include <thread>
#include <chrono>
#include "TaskGenerator.h"
using namespace std;

const int NUMBER_OF_TOKENS_FOR_UUID = 5;
const int NUMBER_OF_DIGITS_FOR_TOKEN = 4;
const int NUMBER_OF_VALUES_FOR_DIGIT = 9;
const int TASK_UNITS_LOWER_VAL = 3;
const int TASK_UNITS_UPPER_RANGE_VAL = 7;
const int GENERATOR_SLEEP_LOWER_VAL = 5;
const int GENERATOR_SLEEP_UPPER_RANGE_VAL = 20;

TaskGenerator::TaskGenerator(string file_name){
    this->file_handler = new CSVhandler(file_name);
}

TaskGenerator::~TaskGenerator(){
    delete this->file_handler;
    this->file_handler = NULL;
}

void TaskGenerator::run(){
	while(true){
	    // sleep for some time
        int time_to_sleep = this->getSleepTime();
        cout << "sleeping for " << time_to_sleep << endl;
        this_thread::sleep_for(chrono::milliseconds(time_to_sleep));
		// append a new task to the file
		this->generateTaskAndAppend();
	}
}

string TaskGenerator::uuidGenerator(){
    string uuid="";
    srand (time(NULL));
    for(int index=0;index< NUMBER_OF_TOKENS_FOR_UUID;index++){
        for(int digit=0;digit<NUMBER_OF_DIGITS_FOR_TOKEN;digit++)
            uuid+=(rand()% NUMBER_OF_VALUES_FOR_DIGIT+1)+'0';
        uuid+='-';

    }
    uuid.pop_back();
    return uuid;
}

int TaskGenerator::taskUnits(){
    srand (time(NULL));
    return rand()%TASK_UNITS_UPPER_RANGE_VAL + TASK_UNITS_LOWER_VAL;
}

int TaskGenerator::getSleepTime(){
    srand (time(NULL));
    return (rand()%GENERATOR_SLEEP_UPPER_RANGE_VAL+GENERATOR_SLEEP_LOWER_VAL)*1000;
}

void TaskGenerator::generateTaskAndAppend(){
    string uuid = this->uuidGenerator();
    int processing_units = this->taskUnits();
    tuple<string,int> task (uuid,processing_units);
    cout << "New task is generated " << uuid << " " << processing_units << endl;
    this->file_handler->writeCSV(task);
}