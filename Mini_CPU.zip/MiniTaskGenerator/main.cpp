#include <string>
#include "TaskGenerator.h"

using namespace std;

/*
 * main function, to run it you need
 * MiniTaskGenerator.exe <path to file to store the tasks>
 */
int main(int argc,char* argv[]){
	//Mohammad Khamlan//11819287
    if(argc == 1){
        cout<< "you need to give the path to the file";
        return -1;
    }

    // the first value in the argv array is the program name
    // the second one is the file path
	TaskGenerator* generator = new TaskGenerator(string(argv[1]));
    // start generating tasks
   /* CSVhandler C("tasks.csv");
    vector<tuple<string, int>>result = C.readCSV();
    for(int i=0;i<3;i++)
        cout << get<0>(result.at(i)) << "/t"<<get<1>(result.at(i)) << endl;*/
    generator->run();
}
